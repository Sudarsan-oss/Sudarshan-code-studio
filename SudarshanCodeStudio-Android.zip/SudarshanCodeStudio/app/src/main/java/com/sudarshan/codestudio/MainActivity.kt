package com.sudarshan.codestudio

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.documentfile.provider.DocumentFile
import androidx.compose.ui.platform.LocalContext

// ---------- Brand colors (same palette as the web prototype) ----------
private val BgVoid = Color(0xFF0A0B10)
private val BgPanel = Color(0xFF12131C)
private val BgElevated = Color(0xFF181A26)
private val AccentViolet = Color(0xFF8B5CF6)
private val AccentCyan = Color(0xFF2DD4E0)
private val TextPrimary = Color(0xFFE9EBF5)
private val TextMuted = Color(0xFF7D84A0)
private val Danger = Color(0xFFF2495C)

sealed class Screen {
    object FolderPicker : Screen()
    data class FileList(val folderUri: Uri) : Screen()
    data class Editor(val fileUri: Uri, val fileName: String, val initialContent: String) : Screen()
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                background = BgVoid,
                surface = BgPanel,
                primary = AccentViolet,
                secondary = AccentCyan,
                onBackground = TextPrimary,
                onSurface = TextPrimary
            )) {
                Surface(color = BgVoid) {
                    AppRoot()
                }
            }
        }
    }
}

@Composable
fun AppRoot() {
    val context = LocalContext.current
    var screen by remember { mutableStateOf<Screen>(Screen.FolderPicker) }
    var statusMessage by remember { mutableStateOf<String?>(null) }

    val folderPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { uri: Uri? ->
        if (uri != null) {
            // Keep permission across app restarts
            context.contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
            screen = Screen.FileList(uri)
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        when (val s = screen) {
            is Screen.FolderPicker -> FolderPickerScreen(
                onPickFolder = { folderPicker.launch(null) }
            )
            is Screen.FileList -> FileListScreen(
                folderUri = s.folderUri,
                onOpenFile = { fileUri, fileName, content ->
                    screen = Screen.Editor(fileUri, fileName, content)
                },
                onChangeFolder = { folderPicker.launch(null) },
                onStatus = { statusMessage = it }
            )
            is Screen.Editor -> EditorScreen(
                fileUri = s.fileUri,
                fileName = s.fileName,
                initialContent = s.initialContent,
                onBack = { screen = Screen.FileList(lastFolderUri ?: s.fileUri) },
                onSaved = { statusMessage = "Saved ${s.fileName}" }
            )
        }

        statusMessage?.let { msg ->
            LaunchedEffect(msg) {
                kotlinx.coroutines.delay(2000)
                statusMessage = null
            }
            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 24.dp)
                    .background(BgElevated, shape = MaterialTheme.shapes.medium)
                    .padding(horizontal = 16.dp, vertical = 10.dp)
            ) {
                Text(msg, color = TextPrimary, fontSize = 13.sp)
            }
        }
    }
}

// Remembers the last opened folder so "Back" from the editor returns to the right list
private var lastFolderUri: Uri? = null

@Composable
fun FolderPickerScreen(onPickFolder: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(Icons.Filled.FolderOpen, contentDescription = null, tint = AccentViolet, modifier = Modifier.size(56.dp))
        Spacer(Modifier.height(18.dp))
        Text("Sudarshan Code Studio", color = TextPrimary, fontSize = 20.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text(
            "Pick a folder on your phone to open it as a project. You'll get real read & write access to its files.",
            color = TextMuted, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 12.dp)
        )
        Spacer(Modifier.height(24.dp))
        Button(
            onClick = onPickFolder,
            colors = ButtonDefaults.buttonColors(containerColor = AccentViolet)
        ) {
            Icon(Icons.Filled.FolderOpen, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("Open Folder")
        }
    }
}

@Composable
fun FileListScreen(
    folderUri: Uri,
    onOpenFile: (Uri, String, String) -> Unit,
    onChangeFolder: () -> Unit,
    onStatus: (String) -> Unit
) {
    val context = LocalContext.current
    lastFolderUri = folderUri
    var files by remember(folderUri) { mutableStateOf<List<DocumentFile>>(emptyList()) }
    var showNewFileDialog by remember { mutableStateOf(false) }
    var refreshTrigger by remember { mutableStateOf(0) }

    LaunchedEffect(folderUri, refreshTrigger) {
        val root = DocumentFile.fromTreeUri(context, folderUri)
        files = root?.listFiles()?.filter { it.isFile }?.sortedBy { it.name } ?: emptyList()
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // Top bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(BgPanel)
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text("Sudarshan Code Studio", color = TextPrimary, fontSize = 16.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
                Text(
                    DocumentFile.fromTreeUri(context, folderUri)?.name ?: "project",
                    color = TextMuted, fontSize = 11.sp
                )
            }
            IconButton(onClick = onChangeFolder) {
                Icon(Icons.Filled.SwapHoriz, contentDescription = "Change folder", tint = TextMuted)
            }
        }

        if (files.isEmpty()) {
            Column(
                modifier = Modifier.fillMaxSize().padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(Icons.Filled.InsertDriveFile, contentDescription = null, tint = TextMuted, modifier = Modifier.size(40.dp))
                Spacer(Modifier.height(10.dp))
                Text("This folder is empty", color = TextMuted, fontSize = 13.sp)
            }
        } else {
            LazyColumn(modifier = Modifier.weight(1f).padding(8.dp)) {
                items(files) { file ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .background(BgPanel, shape = MaterialTheme.shapes.medium)
                            .padding(14.dp)
                    ) {
                        Icon(Icons.Filled.Description, contentDescription = null, tint = AccentCyan)
                        Spacer(Modifier.width(10.dp))
                        Text(
                            file.name ?: "unnamed",
                            color = TextPrimary,
                            fontSize = 14.sp,
                            modifier = Modifier
                                .weight(1f)
                                .clickable {
                                    val content = try {
                                        context.contentResolver.openInputStream(file.uri)
                                            ?.bufferedReader()?.readText() ?: ""
                                    } catch (e: Exception) {
                                        onStatus("Couldn't read file: ${e.message}")
                                        return@clickable
                                    }
                                    onOpenFile(file.uri, file.name ?: "unnamed", content)
                                }
                        )
                    }
                }
            }
        }

        // New file FAB row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.End
        ) {
            FloatingActionButton(
                onClick = { showNewFileDialog = true },
                containerColor = AccentViolet
            ) {
                Icon(Icons.Filled.Add, contentDescription = "New file", tint = Color.White)
            }
        }
    }

    if (showNewFileDialog) {
        var newName by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showNewFileDialog = false },
            title = { Text("New file") },
            text = {
                OutlinedTextField(
                    value = newName,
                    onValueChange = { newName = it },
                    placeholder = { Text("filename.txt") },
                    singleLine = true
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    val root = DocumentFile.fromTreeUri(context, folderUri)
                    if (root != null && newName.isNotBlank()) {
                        root.createFile("text/plain", newName)
                        refreshTrigger++
                        onStatus("Created $newName")
                    }
                    showNewFileDialog = false
                }) { Text("Create") }
            },
            dismissButton = {
                TextButton(onClick = { showNewFileDialog = false }) { Text("Cancel") }
            }
        )
    }
}

@Composable
fun EditorScreen(
    fileUri: Uri,
    fileName: String,
    initialContent: String,
    onBack: () -> Unit,
    onSaved: () -> Unit
) {
    val context = LocalContext.current
    var content by remember(fileUri) { mutableStateOf(initialContent) }
    var isDirty by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(BgPanel)
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Filled.ArrowBack, contentDescription = "Back", tint = TextPrimary)
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(fileName, color = TextPrimary, fontSize = 14.sp)
                if (isDirty) Text("unsaved changes", color = AccentCyan, fontSize = 10.sp)
            }
            IconButton(onClick = {
                try {
                    context.contentResolver.openOutputStream(fileUri, "wt")?.use { out ->
                        out.write(content.toByteArray())
                    }
                    isDirty = false
                    onSaved()
                } catch (e: Exception) {
                    // Surface failures via the dirty flag rather than crashing
                    isDirty = true
                }
            }) {
                Icon(Icons.Filled.Save, contentDescription = "Save", tint = AccentCyan)
            }
        }

        TextField(
            value = content,
            onValueChange = {
                content = it
                isDirty = true
            },
            modifier = Modifier
                .fillMaxSize()
                .background(BgElevated),
            textStyle = TextStyle(
                fontFamily = FontFamily.Monospace,
                fontSize = 14.sp,
                color = TextPrimary
            ),
            colors = TextFieldDefaults.colors(
                focusedContainerColor = BgElevated,
                unfocusedContainerColor = BgElevated,
                focusedIndicatorColor = Color.Transparent,
                unfocusedIndicatorColor = Color.Transparent,
                cursorColor = AccentCyan
            ),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text)
        )
    }
}
